from flask import Flask, render_template, request, jsonify
import openai

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = ''

def get_openai_response(user_input):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a professional tweet creator."},
            {"role": "user", "content": user_input},
        ]
    )
    return response.choices[0].message['content']

@app.route('/')
def home():
    return render_template('new.html')

@app.route('/generate', methods=['POST'])
def generate():
    company_name = request.form['question1']
    product_name = request.form['question2']
    user_profile = request.form['question3']
    print(company_name, product_name, user_profile)
    user_input = "Write the first 30 Tweets for my company "+company_name+". Our main product revolves around " +product_name+" and the ideal user is "+user_profile+". Rules: 1. No hashtags 2. Tweet 1-5 should be about the launch 3. Tweet 6-10 should be about the problem the product solves 4. Tweet 11-15 should be about how the product solves the problem 5. Tweet 16-20 should be about testimonials 6. Tweet 21-25 should be funny and engaging content 7. Tweet 26-30 should be about the roadmap of the company's product.Each tweet should be compulsorily start with \n"

    response = get_openai_response(user_input)

    # Split the generated text into lines
    lines = response.split('\n')
    
    

    
    return render_template('new.html', lines=lines)

if __name__ == '__main__':
    app.run()
